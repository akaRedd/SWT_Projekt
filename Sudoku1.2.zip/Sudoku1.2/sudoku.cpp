Sudoku::Sudoku()
{
  playing = false;
}

Sudoku::~Sudoku()
{
}
